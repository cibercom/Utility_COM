# 📦 Cxxdroid Libraries (Free)

A simple guide to install **paid Cxxdroid libraries** (without modifying or installing a modded APK).  
This method works for both **ARM** and **ARM64** architectures.

- Allegro **5.2.7**  
- SFML **2.5.1**

---

## 🚀 Getting Started

### 1. Install Cxxdroid
Download and install **Cxxdroid** from the official Play Store:  

<a href="https://play.google.com/store/apps/details?id=ru.iiec.cxxdroid">
  <img src="https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png" width="200"/>
</a>

---

### 2. Install Libraries
Run the following commands directly in the **Cxxdroid terminal**.

#### 📘 Allegro
```bash
wget https://raw.githubusercontent.com/theshoqanebi/cxxdroid-libraries-free/main/allegro.sh -O - | sh
```

#### 📗 SFML
```bash
wget https://raw.githubusercontent.com/theshoqanebi/cxxdroid-libraries-free/main/sfml.sh -O - | sh
```

---

## ⚠️ Notes
- This does **not** require a rooted device or a modified APK.  
- Scripts will automatically download and set up the required libraries.  
- Confirmed working on **Cxxdroid v5.0 → v5.42**, and expected to work on future updates.  
- Make sure you have a stable internet connection before running the commands.  

---

## 📜 License
This project is for **educational purposes only**. Please respect the original Cxxdroid developers and support them if you find the app useful.
