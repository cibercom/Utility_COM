#include <iostream>
#include <cstdlib>
#include <string>
#include <cmath>

int main() {
    // 1. Indicar al navegador que responderemos con HTML
    std::cout << "Content-type:text/html\r\n\r\n";

    // 2. Obtener datos del formulario (GET)
    char* data = getenv("QUERY_STRING");
    double radio = 0;
    
    if (data != nullptr) {
        // Parseo simple para obtener el valor de 'radio'
        std::string s(data);
        radio = std::stod(s.substr(s.find("=") + 1));
    }

    // 3. Procesar datos
    double area = M_PI * std::pow(radio, 2);

    // 4. Generar HTML de salida
    std::cout << "<html>\n";
    std::cout << "<head><title>Resultado C++</title></head>\n";
    std::cout << "<body>\n";
    std::cout << "<h2>Resultado del Calculo</h2>\n";
    std::cout << "<p>Radio ingresado: " << radio << "</p>\n";
    std::cout << "<p>El area calculada en C++ es: " << area << "</p>\n";
    std::cout << "<a href='/formulario.html'>Volver</a>\n";
    std::cout << "</body>\n";
    std::cout << "</html>\n";

    return 0;
}