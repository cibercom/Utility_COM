	Clean_drill_duplicate.vbs v1.0
	________________________

Clean_drill_duplicate is a script to clean drill files from hole duplicates.
When two holes are present on the same location or so close that they overlap each other, it's seen as an error  by the manufacturer. This script will delete all holes whose coordinate are either exactly the same or almost the same. 

Use:
___

Copy the script in the folder where the drl file(s) is (are) located. Double-click. Follow instructions poping up on message boxes. If you don't want to read the messages, hit "enter" three or four times quickly until all message boxes are gone.
You can copy this script to as many folders as you want.

It doesn't delete the original file. It creates a copy named after the drl file + "_clean".

It will process all the *'drl files present in the folder where the script has been copied. If there are more than one drl file in the folder, it will let you confirm for each file unless you decide to let him process without confirmation.

If the difference in the  coordinates is very small it will be regarded as a duplicate and deleted. The first instance will be kept while all the other instances will be deleted.
Two holes don't have to get exactly the same coordinate to be considered for deletion.

It will delete duplicates regardless of the size of the hole but it will always keep the largest hole size and delete the smaller ones. 

This script has been tested with files generated with FreePCB 2 and 1.

_________________

Term of Use:

Free to use.

You can distribute the unmodified version as you will, as long as you include this readme file with it.

You can modify the current script for your personal purpose but not distribute modified versions.

Disclaimer:
The author of this script is not responsible for any damage, material loss, loss or alteration of data, malfunction or any unwanted consequence cause directly or indirectly by the use of this script.
Use at your own risk.
_________________

(c) Frederic Hage 2020

