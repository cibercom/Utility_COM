https://www.almanac.com/content/measurements-and-conversions-chart

	Dingue Calculator v 2.3 Beta
	=========================
ATTENTION: v 2.3 Beta was not fully tested. Bugs, or failed opertions are possible.

Written by Frederic Hage for HTAsoft, projects@htasoft.com
________________________________

DESCRIPTION:
An easy to use, yet fully featured multipurpose calculator and unit convertor.

LICENSE:
Freeware.

FEATURES:

-See the operation you are typing and allow re-editing it before calculating the result*
-Convert many units to many units including data storage
-Compose complex units with no limitation
-Convert currencies with with a customized currency list
-Use of customized variables
-Use of demultiplier symbols such as K,M,G and T to avoid typing large numbers
-Optionaly reduce the lenght of the result by using demultiplier symbols such as K,M,G and T
-Optionaly reduce the number of decimals
-Optionaly separates thousands with white spaces
-Switch back to the previous operations to re-edit them ("Previous/Next" buttons)
-See a full list of the operations that you have been doing with copy-paste allowed
-Save the operations and the results as a text file.
-Calculate percents of a certain number or how many percent this number is in another one
-Gives value of Pi
-Use "V" symbol for square root, visualy closer to classic math, also works with or without parenthesis.
-Cos(X) Sin(X) Tan(X) etc works with or without parenthesis.
-Optionaly gives help and tips on the fly
-Use buttons or type symbols manualy as you like
-Intuitive, customizable, skinable HTA interface, in another word: Cool!

*(With the default calculator which imitate a standard handheld calculator, the calculation is 
processed immediately after an arithmetic operator is entered, preventing any complex operations.)
________________________________

SOFTWARE REQUIREMENT: Any Windows OS.
	--------
Requirement for non-updated Windows 98 or under: Windows Script 5.6
Link:   http://www.htasoft.com/w98se_post_usp4/SCR579X.EXE
info:    http://www.htasoft.com/w98se_post_usp4/SCR579X.txt
________________________________

INSTALLATION

-There is no need for an installer: Extract all the files to the directory where it suits you best (no further installation necessary).

			VERY IMPORTANT: 

	On Windows VISTA/7 or later you cannot install this program in  "Program Files" or in "Windows" or one of their subfolders.
	I recommand to install it inside the "Public" folder or subfolder or in one of the user's "Document" subfolder.

	On Xp avoids the "Windows" folder. The best is still to follow the rules for Vista.

	On w98, you can install it wherever you want. 

-To run the program double-click "Calculator*.hta". (The asterisk represent the program version)

-If you want, create manualy a shortcut to your desktop or to the quick launch linking to this file.
To do that, drag and drop the file by pressing the right-click mouse button. Upon dropping the file, select "create shortcut here".
________________________________

HOW TO USE?

Doubleclic on Calculator*.hta
Then type in the input box the arithmetic operation you want to do, for example:

12+25 

...or a more complicated one:

123/((12*5.32*1)+V3*4V6000)+0.12*Cos12-pi

...then hit the "ENTER" key energicaly or click "Calculate"!
Well, I hope the interface is intuitive enough and that you don't need to read anything more. Save the very important warning bellow.
If something is not clear when you use this program, just look here.
________________________________________

USE OF DOTS AND COMAS
			************************************************
							VERY IMPORTANT:
			DO NOT USE COMAS OR DOTS AS THOUSANDS SEPARATORS.
						Use white spaces instead!
			*************************************************
I could have set an option to allow the user to choose what to use as thousands separators, 
but I prefer not to do so in order to avoid mistakes in case of wrong configuration.
Whit white spaces there is no mistake wherever is your location in the world.

Dots and comas are always interprated as decimal separators.
This means that you can use a dot or a coma as decimal separator no matter your region or your computer settings.
For example: 2.3 will be the same as 2,3
but 2,300 will be read as 2.3 and 2.300 will also be read as 2.3!
2.300.200 will return an error.
			
USE OF WHITE SPACES
You can use as many white space as you want, wherever you want even several white space in a row.
It doesn't have to be thousand separators. Whte spaces are simply ignored.

USE OF SQUARE AND CUBIC SYMBOLS
You can write � and � as well as simple 2 and 3 to mark them as square and cubic.
This works with units as well as root numbers (V)
Example: �V and 4� and m� are all accepted.

USE OF DEMULTIPLIER SYMBOL
To make your formula shorter and simplier you can use demultiplier symbol such as K,M,G or T.
This will avoid typing long series of zeroes when working with large numbers.

	K (Kilo) multiplies the number by 1000.
	M (Mega) multiplies the number by 1000 000.
	G (Giga) multiplies the number by 1000 000 000.
	T (Tera) multiplies the number by 1000 000 000 000.
	-  or nothing doesn't multiply. (see "DingueCalculator.ini")

Example:
3.25M wil be equivalent to 3250000 (3 million 250 thousands)
Example:
1.5M + 250K will return 1750000

ATTENTION: These are the only symbols which are case sensitive.
This means that "M" won't mean the same thing as "m".
"M" will mean "million" while "m" will mean "meter".

You can also ask the program to use these symbols in the result. See Output Options below.
________________________________

INI FILES

You can edit preference directly in  "DingueCalculator.ini".
 0=No, -1=Yes
Except for:
Demultiply (see DEMULTIPLIER SYMBOL above. Keep brackets)
SaveFolder (type in a folder path. Keep brackets)

You can edit units in "Units2.ini"
The base unit is the one with the value 1. You must always calculate the value of a new unit according to the base unit.
For example: For distances, the base unit is meter (=1). If you want to add mile in the list , you have to calculate how many meters in a mile and enter the result mile [mi]=1609.34
(it's already there but it was an example)
Do NOT try to change the base unit.

ATTENTION:
Symbols are case sensitive 
All letters must be lowercase except the letter M.

"LoadDatas2.ini" contains interface data. Don't modify this file.
________________________________


KNOWN BUG
Sometimes the "Prev" button (show previous operation) is greyed out whereas there was an operation before (usualy it happens with the first operation done during the session). To see the previous operation in this case, you need to press twice "Next" then, one more time "Prev".
________________________________

OUTPUT OPTIONS

REDUCE THE LENGHT OF THE RESULTING NUMBER BY USING A DEMULTIPLIER SYMBOL (K,M,G or T)
This is very useful when working with high numbers.

	K (Kilo) will divide the result by 1000 and add the symbol "K" at the end.
	M (Mega) will divide the result by 1000 000 and add the symbol "M" at the end.
	G (Giga) will divide the result by 1000 000 000 and add the symbol "G" at the end.
	T (Tera) will divide the result by 1000 000 000 000 and add the symbol "T" at the end.

This function is disabled when the result is inferior to 1/10th of the demultiplier.
For example if the result is 90 and the demultiplier symbol is K (1000), the function will ne be triggered 
and it will read "90".
If the result is 200, then it will read "0.2K".

In the ini file, enter "" (empty quote string) to disable this function. In the ini file, the symbol must always 
be contained within doublequote marks (example: Demultiplier = "K").
You can use these multiplier symbols in your formula as explained above.

REDUCE THE NUMBER OF DECIMALS
The number of decimals will be reduced down to the number of decimal entered. It will also remove unnecesary zeroes.
In the ini file, enter -1 to disable this function.

SEPARATE THOUSANDS WITH WHITE SPACES
This will improve the readability of long numbers.

Why not separating thousands with comas? 
Because different regions of the world use either a dot or a coma to separate thousands so I decided to use white spaces to avoid problems with the program.
___________________________________

INTERFACE OPTIONS

Changing the display option doesn't remove or disable the function shown by the buttons.
All the funtions remain accessible through the keyboard.
Typing function or symbols manualy have the same effect as pressing the button to include them in the formula.

Click the "Options" button, then click "OK" or "Minimalist view" to get the smallest window possible.
While under minimalist view, click the "..." button to return to the option table.

Show convertions unit lists and buttons
	(Useful for finding the right unit symbol when doing conversions. Conversions work also when this option is disabled)

Show scientific operators such as Cosinus, Tangent etc
	(If you never use them, uncheck this option)

Show simple operators such as +, - , 'V etc
	(They are on your keyboard or very simple to type, so in fact you don't realy need these buttons. You will notice that I didn't even bother designing a number pad - that's the originality of this calculator! -)

Show computer interpretation string
	(Usualy, you don't need this. It shows how the computer has interprated what you have written with the intiutive interface. It's useful to debug errors or see what happened when the result looks very wierd. It can be also useful when doing important works and check if the formula entered had been properly written. Interpretated strings are also valid formulas and even recomanded.)

Show the mathematic operation that had been done
	(Shows the formula which gave the curent result)

Show list of previous operations
	(Shows all the operations you have done during the session. The list is erased once you close the program. Use the "Save" button to save it in a separate text file)

Show tips
	(To disable once you have read them all...)
	
Show result display options
	(This will show the setting menus for the number of decimals, thousands separator and the demultiplying factor so that these options can be modified easily at every operation.)

DISLAY OPTIONS

Display:   o Normal   o Horizontal   o Vertical    o Full Screen

	Norma: Will cover the screen area partialy in a proportionate rectangle
	Horizontal : Will strech the window to screen width and display item horizontaly with minimal height.
	Vertical : Will strech the window to screen height and display item vertically with minimal width.
	Full Screen: Will cover the entire area of the screen. 

Options are saved in "DingueCalculator.ini".
________________________________

UNIT CONVERTION

This is very simple. Just type the usual symbols.
At the end of the formula, type "?" followed by the unit you want to convert to.

Example for converting centimeters into feet:
563cm?ft

It's recommanded to ALWAYS TYPE THE UNITS IN LOWER CASE.
Especialy for the symbols k,m,g and t which in upper case are interpretated as multipliers and the letter v.
(see above)

CONVERSION WITHIN A CALCULATION
You can use the conversion within a calculation:
Example:
45m + 2km?mi
will calculate 45 meters + 2 kilometers and give the result in miles

If you don't type ? followed by a unit, the last unit in the formula will be used for the convertion
Example:
45m + 2km
will convert 45 meters + 2 kilometers into kilometers

Attention you must always assign a unit after each number or use parenthesis.
Example:
40 km +5km + 2000m?mi
or
(40+5)km + 2000m?mi
and not
40 +5km + 2000m?mi

In fact a unit is equivalent to using the   *    sign. It multiplies the number or the parenthesis before it.

COMPLEX CONVERSION UNITS
You can compose complex units by using "/" between two or three symbols.
Example: kw/h/bar, kg/m�/s, floz/min, gal/sqft, km/s, etc

Variations are only limited by your imagination.

Are also accepted the common following symbols: 
mph (mile per hour), mps (mile per second), sqin (square inch), cuin (cubic inch), sqft (square foot), cuft (cubic foot), sqyd (square yeard), cuyd (cubic yard), sqmi (square mile), cumi (cubic mile).

USE OF SQUARE AND CUBIC SYMBOLS IN UNITS
You can write � and � or simple 2 and 3 to mark them as square and cubic.
Example: m2 and m� are both accepted.

FEET AND INCHE SYMBOLS
You can use ' (for feet) and " (for inches) instead of ft and inch.

In the case of feet and inches used together (and in this case only, not with other units) 
there is no need to add a + between feet and inches.
For example:
5'3"
will be equivalent to 
5 feet + 3 inches
________________________________

DATA STORAGE UNIT CONVERTION

Dingue Calculator allows two uses of data size unit symbols. 
One commonly using only Kb, Mb, Gb etc and the IEC prefix convention using Kib and Kb, Gib and Gb etc. 

What's the effect of enabling "GiB" IEC convention?
When "Gib" convention is enabled the symbols "Kb", "Mb", "Gb" and "Tb" will multiply
by 1000, 1000 000, 1000 000 000 and 1000 000 000 000 respectively instead of 1024, 1024*1024 etc.
In this case you need to use the symbols "Kib", "Mib", "Gib" and "Tib" to multiply by 1024, 1024*1024 etc.

Example:
Enabled: 1KiB = 1024b <u>but</u> 1Kb = 1000b
Disabled: 1KiB <u>and</u> 1Kb = 1024b

More informations on Wikipedia (http://en.wikipedia.org/wiki/Binary_prefix) or in "GibConvention.hta".
________________________________

CURRENCY CONVERTION
The file "currencies.txt" contains a list of currencies and their value in US dollar as of 14th of May 2010.

	!!! YOU MUST UPDATE THE EXCHANGE RATES MANUALY BEFORE CONVERTING CURRENCIES !!!
	
To do that you can go there if you don't know where to find exchange rates:
http://www.x-rates.com/d/USD/table.html
(This website has no relation whatsoever with the author of this software - you can go to any other source of course)

There is no automatic currency rate updator with this program.
Therefore you are the only one responsible for the accuracy of the exchange rates.
Of course, you can update only the rates of the currencies you need at your own discretion.
You can edit the list of currencies manualy in Notepad or similar text editor.
You can add or remove entries. The list proposed is only a sample.

Each entry consist of one currency on one line with a description, its symbol and its value relative to the US dollar.
The symbol is what will be used in the formula and must be written under brackets after the descripton.
The value relative to the US dollar must be indicated after the   =   sign.

Symbols must be written with simple letters or numbers, without any accent, punctuation mark, symbol, non-latin character, hieroglyphe or any non-alphanumeric character.

Here is an example of one entry:
Pound Sterling [GBP] = 1.4756

The description is everything before the first open bracket [ . Here: Pound Sterling.
The symbol is what is between brackets []. Here: GBP
The value is a number following = . Here: 1.4756

US dollar (USD) is equal to 1.

In the calculator type the international symbol of the currency or click in the list of currencies.
You can type them in lower or in upper case. It makes no difference.

In the list provided, you can enable more currencies by removing the   '   sign in front of it. To disable a currency add a   '   sign in front of it. This is useful to make the currency list in the calculator shorter.

COMMON CURRENCY SYMBOLS SUPPORTED:

$ (Alt+36)   = US Dollar [USD]
� (Alt+0128) = Euro [EUR]
� (Alt+0163) = Pound Sterling [GBP]
  (Alt+0165) = Japanese Yen [JPY]
________________________________

CUSTOMIZED VARIABLES

Customized variables are your personal variables, that you create yourself.
Attention: These variables cannot be used as convertion units. They basicaly replace numbers that you want to use often.
(If you need a customized convertion unit you can add it in the currency list.)

They are listed in "my_variables.txt". The format is the same as for the currency list.
Each variable has a name and a symbol: The name is for description only.
The symbol is what will be used in the formula and must be written under brackets after the descriton.
The value must be indicated after the = sign.

Variable symbols must be written with simple letters or numbers, without any accent, punctuation mark, symbol, non-latin character, hieroglyphe or any non-alphanumeric character.

IT'S RECOMMANDED THAT EVERY CUSTOMIZED VARIABLE SYMBOL BE PRECEDED BY "$".
Example:

Mumu [$M] = 4.5

This is necessary to avoid errors and confusion when you name a variable the same as an existing, hard-coded conversion unit.
For example if you name a variable "m", you will have to type "$m" in the calculator so that it will know that you mean your personal variable "$m" and not the lenght unit "meter".

Exceptions to this rule are x, y and z because we are sure that they don't exist anywhere else in the program.
You can try other variable symbols without $ but you risk creating an error either because the symbol is already a measure unit symbol, a currency symbol, a variable used by the program itself or an mathematical operator.

If you type $ alone, well,... it will be interpretated as USD, the currency symbol for american dollar!

Please note that the names of your variables is NOT case sensitive. 
This means that the variable "$joe" will be the same as "$JOE", "$jOe" and "$Joe".

Like with the currencies, you can enable or disable variables by removing or adding the   '   sign in front of it.

Finaly, You can write a longer description at the end of the line, after a single quote mark (or apostrophe) like this:  '   .
Example:

My test[$test]=1.5   ' This is what I use for testing

USING CUSTOMIZED VARIABLES

When you use such variable in conjunction with a unit symbol (eg: "ft") or other letters meaning something (eg: "Cos"), you must include the variable within parenthesis but not with  non-alphabetic symbols  (eg:   +  -  *  /   ) and not with "V".
Examples with the variable "x":

Cos(x)
but not
Cos x

(x)ft
but not
x ft

This doesn't apply to non-alphabetic symbols
Example:

x+y
will not give any error and will addition the two variables

With the symbol "V" (square root), the variable symbol can be used without parenthesis.
Example:

3Vx
will not give any error and will give the cubic root of x.

3V(x)
will not give any error and is the same as above

xV25
will not give any error and will give the root of 25 as x as root power. If x=2, it will give the square root of 25 for instance.

(x)V25
will not give any error and is the same as above

xVy
is also a valid combination
(Attention "V" must always be written in uppercase, not "v")
________________________________

SAVING THE RESULTS TO A FILE

There is a "Save" button near the list of previous operations.

If the list of operations is not showing and you don't see this button, click the "Options" button and enable "Show the mathematic operation that had been done".
Change the destination folder in the Options if necessary. Then click "Ok".

Click "Save" and enter a file name in the input box which just poped up and here you go.

________________________________

TIPS TYPING FORMULAS

Every command is typeable on the keyboard. Typing a symbol is exactely the same as getting it by pressing a button.
So in theory, it's possible to use all the functions without clicking any button, even without seeing these buttons at all.
--------------------
Type " pi " to have the value of Pi.
Example:
pi + 1
= 3.1415926536 + 1 = 4.1415926536

--------------------
Type " ^ "  to raise a number to the power of an exponent. 
Example:
4^2
 = 16

Note that   �   and   �  are both valid symbols equivalent to  ^2  and  ^3   .

--------------------
Type "V" (UPPERCASE!) to get the square root of a number.
Example:

V16
= 4

"V" must always be written in uppercase, not "v"
Example:

v16
= Error

If you type "V" without parenthesis, only the first number following "V" will be included in the "V" square root range.
Example:
4+V16+3
 = 4+4+3 = 11

If you type "V" with parenthesis, the string included in the parenthesis will be under the "V" square root range
Example:
4+V(10+6) +2
= 4+V16 + 2 = 4+4+2 = 10

If you type a number before "V", it will give the root power of this number (root power limited to two digits).
Example:
4V256
= 4

4+4V256
= 4+4 = 8

4+4V(200+56)
= 4+4V256 = 4+4 = 8

4+4V256+2 
= 4+4+2 = 10

4+4V(200+56) +2
=4+4V(256)+2 = 4+4+2 = 10

NOTE: In the text returning the formula  "V" will be transformed to a an equivalent form of "^(1/2)" 
and "3V" will be transformed to a an equivalent form of "^(1/3)" etc.

NOTE: You can use "pi" as a root power.
Example: piV253614

You can also use "sqr( )" or "^(1/2)" instead of "V"
Example:

sqr(16)+sqr(25) or 16^(1/2)+25^(1/2) or V16+V25
= 4+5 = 9

--------------------
To count  x "is how many percents of" y:

formatpercent(x/y)

or if you want to compare complex operations use

FormatPercent((  x  )/(  y  ))

Why is there double parenthesis in this formula? Because if you replace x or y by a complex operation, it will give you a wrong result with these additional parenthesis.
Example:
FormatPercent((  25*36  )/(  856-56  ))
but not
FormatPercent(  25*36  /  856-56  )

For the same reason it allows to use convertion units in this formula.
Example:
FormatPercent((  25 m2  )/(  56 sqft  ))
Will count how many percent makes 25 square meters in 56 square feet.

Replace x and y by numbers. Otherwise the value for x and y will be defined in the list of customized variables in "my_variables.txt".

--------------------
Works with or without parenthesis:
Note that with custom variables, because they are not numeric, need to be between parenthesis anyway. Otherwise their name will melt with the operator name.
If you are confused, always use parenthesis.

Tangent 
Tan(X)

ArcTangent 
Atn(X)

Cosinus 
Cos(X)

Sinus 
Sin(X)

Logarithm 
Log(X)

Returns e (the base of natural logarithms) raised to a power.
Exp(X) 

Examples:

Tan 2
is the same as 
Tan(2)

but

Tan x
will give an error so you must type 
Tan(x)

________________________________

HISTORY
v.0.1
Not released

v.0.2
Not released

v.0.3
First public release

v.0.4
Added batch processing
The whole script was rewritten for better performance

v.0.5
Added setting dialog for default folder and file name to avoid "file not found" error.

v.0.6
Added show the list of the operations that you have been doing in real time

v.0.7
Added squareroot as "V" as well as "Sqr( )" or "^(1/2)"
Added Pi
Added Help

v.0.8
Added unit convertion
Added ini file for settings

v.0.9
Added temperature convertion

v.1.0
Fixed bug with all units including "in" in their symbol (now, symbol for "inch" is "inch")

v.1.1
Remanipulated the whole code mostly for art sake and performance

v.1.2
Fixed a bug in temperature conversion which appeared in v.1.1. This bug didn't exist in previous verions.
Fixed other minor bug with units conversion.

v.1.3
Not released

v.1.4
New user input interpretation engine
More reliable and flexible code to allow new parameters easily
Square root uses "V" uppercase only so that "v" lowercase can be used into variables.
Debug errors when the operation entered is invalid or when the program cannot interpretate it correctly.

v.1.5
Not released

v.1.6
Not released

v.1.7
Ported to HTA interface
Removed batch processing (will be back in a future versions)

v.1.8
Added use of x and y as variable
Fixed a bug with window repositioning
Interface optimization
Minor code improvements

v.1.9
Added number pad :-)
Added customized units
Added currency convertion
Added demultiplier symbols such as K,M,G and T to avoid large numbers
Added use of white space as thousands separators
Added number formating to reduce the number of decimals
Added vertical and horizontal interface display
Added option to use Gib convention in data storage unit convertions
Added ' and " symbols for foot and inch convertion units.
Fixed potential errors with the use of   �  and  �  .
Improved html/css code
Improved and separatedly coded option setting interface
Improved and separatedly coded hard-coded datas loading
Improved code for treating parenthesis with "V" among other minor things

v.2.0
Fixed a glitch with parenthesis in square roots calculations.

v.2.1
Fixed calculation mistake when converting from farenheit to celcius and the number of farenheit degrees was negative
Fixed crash when attempting to convert temperatures. (new error appearing in v.1.9)
Renamed: First zero in the version number removed

v.2.2
Not released

v.2.3
Removed some code from version 2.2, simplified with a new code a little bit
Added "Unit.ini" file. Now units are stored in this file
Added "mil" unit, electronical and electrical units, other unit fractions.
Added dictionary for units, variables, currencies and math operators. Now these things can be added in infinite numbers.
Added automatic menu populating at start up
Added Time and Date operation and some other VBS commands on the interface
Changed how square root is written: 'V or �V when using the "V" symbol. Can also use sqr() or simply ' .
Modified completely "LoadData.ini" and how the program loads the data
Improved code for Celsius to Fahrenheit conversion


________________________________
TERM OF USE
	Free for non commercial purpose.
This scripts is under copyright protection.

This script is provided freely and without warranty. 
The author can not be held responsible for any damage, mistake, financial loss, loss of data or any kind of loss resulting from the direct or indirect use of this script or the inability to use it.

Althought I believe the informations generated by this script to be reliable, it's impossible to guarantee that they will always be acurate.

		 USE AT YOUR OWN RISK!