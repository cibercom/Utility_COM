Clean HTM files v0.1.2
======================
Written by Fredledingue
fredledingo@yahoo.com
________________________
Description:
This VBscript remove all scripts, unsaved images references and other internet connection triggers from the source code of htm and html files saved on your hard disk.

No more red-cross boxes and useless automatic connection.

It also fix the problem with bookmarks (hyperlinks linking to paragraphs inside the same page) that sometimes don't work on or force to re-load the whole page from the internet.

It also write on the page when a link is dead or email (optional)

USE AT YOUR OWN RISK.
________________________
Requirement
	Windows (all version possibly)
	Microsoft Internet Explorer (If not, use SaveUlink_no_IE.vbs)
	Windows Script 5.6 (If you see an error message, please download it from:
http://www.microsoft.com/downloads/details.aspx?FamilyId=0A8A18F6-249C-4A72-BFCF-FC6AF26DC390&displaylang=en
or
http://msdn.microsoft.com/library/default.asp?url=/downloads/list/webdev.asp )
________________________
Installation:
	Unzip the files in a location of your choice
________________________
How to use:
	1/Double-clic on the vbs file (or a shortcut linking to it)
	2/Choose a folder where are the htm files to clean. Clic "cancel" if you prefer pasting the full path of a folder.
	3/All the htm files will be processed at once unless you decide to require a confirmation for each file.
	4/The original files are stored in the same directory in the "Dirty-htm" folder, just incase some data would be missing. If a file of the same already exists in this folder, it will be replaced.
	5/On the clean htm pages, you will see some marks before some hyperlinks :

(x) means the hyperlink will lead nowhere because it's incomplete, so you don't need to click on it. If you do you will always get an "unable to find server" error.

(email) means that it will open your default e-mail editor beacause it's an e-mail address.

If you don't want these marks, clic "No" when asked if you want them.
________________________

Known bugs:
-Broken links inserted in <PRE> tags are not fixed or marked (it will be very diffcult to fix that, but that shouldn't happend often)
-Sometimes a lost code may appear on the clean page.(maybe already fixed)
-Some pages may be not perfectly clean.(maybe already fixed)

Please let me know of problems if any.
________________________

History
v.0.0.4 First release

v.0.0.5 Better method of interpretating the codes, solving many bugs

v.0.0.6 Fixed a potential bug that could give only part of the text (thought I never experienced this bug).

v.0.0.7 Added: Correct bookmarks 
	Added: write if a link is deadline, online or email.
	Added: Input box to copy-paste a folder path instead of browsing for the folder
	Fixed a bug with the <PRE> tag that modified the text display.

v.0.0.8 Fixed an important bug resulting sometimes in loss of datas when deleting notes

v.0.0.9 Fixed several potential bugs
	Re-fixed the bug with the <PRE> tag that modified the text display.
	Added hyperlink marks optional
	Removed note deletions
	Removed the "online" mark and "deadline" has been chaned by "x".
	Other code rewriting for increased performance and speed hopefuly
	Added replace original file is already exists in Dirty_Htm folder

v.0.1.0 Added time estimation and possibility to stop before starting when the time estimate exceed 2.5 sec.
	Original file is not replaced, but renamed if already exists in Dirty_Htm folder.

v.0.1.1 not released

v.0.1.2 Improved bookmark correction
	Re-fixed the bug with the <PRE> tag again
	Fixed other bugs and improved reliability

________________________
Term of use
	Free for non commercial purpose.
(See copyright information inside the script file.)

	DISCLAIMER: Normaly no data should be lost since all files are being duplicated for safety.
However, the author of this script is not responsible for any loss of data caused by the use of this script.
USE AT YOUR OWN RISK.