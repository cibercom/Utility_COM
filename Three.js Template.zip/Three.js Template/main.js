import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

// Set up the scene, camera, and renderer
const guideScene = new THREE.Scene();
const guideCamera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
);
guideCamera.position.set(0, 80, 150); // Adjust the camera position
const guideRenderer = new THREE.WebGLRenderer({ antialias: true });
guideRenderer.setSize(window.innerWidth, window.innerHeight);

// Create a THREE.Color object for the background color
const backgroundColor = new THREE.Color(0xabcdef); // Replace with your desired color code
guideRenderer.setClearColor(backgroundColor);

document.body.appendChild(guideRenderer.domElement);

// Load the GLTF model
const gltfLoader = new GLTFLoader();
gltfLoader.load('guide.glb', (gltf) => {
    const guideObject = gltf.scene;
    const fileAnimations = gltf.animations;

    guideObject.scale.set(1, 1, 1);
    guideScene.add(guideObject);

    // Add lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 3);
    directionalLight.position.set(0, 180, 250);
    guideScene.add(ambientLight);
    guideScene.add(directionalLight);

    // Animation setup
    const mixer = new THREE.AnimationMixer(guideObject);

    // Assuming your animation clip is named 'Take 001'
    const idleAnim = THREE.AnimationClip.findByName(fileAnimations, 'Take 001');
    if (idleAnim) {
        const idleAction = mixer.clipAction(idleAnim);
        idleAction.play();
    }

    // Animation update loop
    const clock = new THREE.Clock();
    function animate() {
        const delta = clock.getDelta();
        if (mixer) {
            mixer.update(delta);
        }

        // Render the scene
        guideRenderer.render(guideScene, guideCamera);

        // Call animate recursively
        requestAnimationFrame(animate);
    }

    // Start the animation loop
    animate();
});

// Handle window resizing
window.addEventListener('resize', () => {
    const newWidth = window.innerWidth;
    const newHeight = window.innerHeight;

    guideCamera.aspect = newWidth / newHeight;
    guideCamera.updateProjectionMatrix();

    guideRenderer.setSize(newWidth, newHeight);
});
