	Context Menu Customizer 0.5 (by Fredledingue)
	_____________________________________________

DESCRIPTION:

-Add, remove, edit items from the context menu for a filetype or a file extention, drives and folders.
-Add, remove, edit Fast Explorer items in the context menu (if Fast Explorer's component installed).
-Modify basic settings for the file type (icon, double-click/open program, caption).
-Interface designed to be as easy as possible for n00bs, GeeKs, ultra-advanced users and even aliens from "Independance Day". ;)

-----------

SYSTEM REQUIEREMENT AND INSTALLATION:

						VERY IMPORTANT:

Because of the system protection implemented on Windows VISTA, I cannot garantee that this program will work on this OS, or that it will be fully fonctional, or that the components will even install.
As you know, on Vista viruses control your computer, not you. :-)

If you want to try it on Vista (perhaps with your configuration, or by reloging as an administrator it will work), please note that you cannot install this program in "Program Files" or in "Windows" or in one of their subfolder.
I recommand to install it inside the "Public" or in one of the user's "Document" folder.

On XP, I recommand using this program as an "Administrator" or with similar privileges.
To install the components, you definetely need to operate as an" Administrator".
Avoids the "Windows" folder for installation.

On w98, you can do what you want. Yeah!

For non-updated w98 ONLY:
-Windows Script Host 5.6 
Link if not yet installed: 
http://msdn.microsoft.com/library/default.asp?url=/downloads/list/webdev.asp
-----------

INSTALLATION:

1/ Unzip all the files into a folder of your choice.

2/ Double-click Install_JcbOcx.vbs (required)(see below)

3/ Double-click Install_FastExplDll.vbs (Optional) 
This component will help you build context menu items with advanced settings (see below)

4/ Files needed to run the program:

Context_Menu_Customizer.hta
CMCustomizer.ini (auto-generated)
PickApp.vbs
PickIcon.vbs
jcb.ocx (will be moved to the system folder, usualy "C:\Windows\System" upon install)
FEShlExt.dll (Optional - will be moved, usualy, to "C:\Program Files\FastExplorer" upon install)
FastExplorer.ini (auto-generated - Optional - usualy in "C:\Program Files\FastExplorer")

-----------

HOW TO USE:

1/ Doubleclick Context_Menu_Customizer.hta

2/ Type a file extention or a filetype in the white box and click the button [Edit Context Menu...].
	______________________
	*        ATTENTION!          *
	*     Other extentions           *
	*  sharing the same filetype  *
	*   will also be affected        *
	______________________

To edit the context menu for folders: type "folder". For drives: type "drive" (without quote).

3/ On top the settings for the filetype corresponding to the extention will be displayed. Click [Modify] to change these settings only. Clicking [Save Settings for this filetype] will only change the filetype settings and will not save modified context menu items.

4/ Below will be displayed the normal items of the context menu. The one with Menu Text: [Open] (with "O" underlined) will be the one used when you double-click on the file.

5/ Below the normal items will be displayed the Fast Explorer items (if installed). Their number correspond to their number in FastExplorer.ini.

6/ The changes will take effect only after you click [Save]. The [Save] buttons will also save filetype settings.
Registry entries which were not modified won't be materialy rewritten in the registry.
You DON'T NEED TO restart your computer or even close the program. Changes take effect immediately.
	
	ATTENTION: Some programs or the Operating System automaticaly reset the context menu and remove the changes you have done. Re-edit it one more time if that happens.

7/ Click on [Edit Context Menu...] again to refresh.

8/ Pressing [Exit] or [x]  or closing the application window will quit the program without saving (if you didn't press [Save] before).
-----------

BUTTONS

1/ [Add] will add a normal item via the registry

2/ [Add Dynamic] will add a Fast Explorer item set to open files selected (when selecting multiple files) in only one session of the program (if it suports that, for example Notepad doesn't, Word does) instead of opening the program as many times as the number of file selected.
It has also the advantage of adding a little icon next to your menu item.
Unlike normal items, Fast Explorer items are stored in FastExplorer.ini (usualy located in the folder "C:\Program Files\FastExplorer").

3/ [Add Script] is an advanced feature for scripters. It will create a Fast Explorer item which will send all the paths of the selected files to the script under the form of Arguments (parameters).
It's useful to run a script straight from the context menu and apply to this script a multiple selection of files. (If you run the script via a normal context menu item, the script will take only one file and will be started as many times as the number of files selected.)

The difference with [Add Dynamic] is that the program to launch will always be Wscript.exe (unless you change that) whilst the path of your script will be sent as a parameter for Wscript.exe and the file selection as a parameter for the script.

Here is an example of code which can be the base of such a script:


	'----Start of script--------
	c=WScript.Arguments.Count
		For i=0 To c-1
		fileList = FileList & WScript.Arguments(i) & VbCrlf
		Next
	MsgBox FileList,,"Test"
	'(Do what you want with the file list from here)
	'-----End of script-------


Currently, script must be saved under *.vbs or *.js files. (Later, I'll add support for hta.)

4/ ["] This button automaticaly adds double quotation marks around the path or the parameter entered.
Wether you need to add them or not depends on the program you will be using. The only way to know that is to test the context menu after you saved the changes.
Click the button once after you entered the new datas. It's equivqlent as typing them yourself but it's faster.

----------
LEGEND

1/ Light-gray color means that this item will be deleted when you will click [Save].

2/ Olive color means that it's a Fast Explorer item which is kept invisible and which can be made effective by making it visible.

----------
BACKUP

If you need to undo the changes without using this application you will find in the "BackUp" folder two types of backed files:

1/ Reg files named after the extention which was modified followed by a number. The highest number is the most recent one.
Doubleclicking these reg file should restore registry keys which were modified or deleted. It won't delete those which were added.

2/ FastExplorer*.ini files (*=some number). The highest number is the most recent one. Just copy one of these file to the Fast Explorer folder (usualy "C:\Program Files\FastExplorer"), move away the file "FastExplorer.ini" and rename the file you moved in to "FastExplorer.ini" by removing the number.
--------------

UNINSTALL:

Doubleclick on "Uninstall_cmc.vbs".
	ATTENTION: The uninstaller won't restore context menus as before except for Fast Explorer items.

If it doesn't work or crashes, follow these instructions:

1/ Click "Start", "Run..."

2/ Type "regsvr32.exe /U " followed by "C:\Windows\System\jcb.ocx" 
(if this is the right short path to jcb.ocx in the System folder)

3/ If you don't use Fast Explorer anymore:
Type "regsvr32.exe /U " followed by "c:\progra~1\fastex~1\feshlext.dll" 
(if this is the right short path to FEShlExt.dll in the Program Files folder)

4/ Delete the above mentioned files except those used by Fast Explorer if still used.

5/ Registry keys generated by the program (other than context menu items)

"HKCU\SOFTWARE\DingueVBS\PickIconFile"
"HKCU\SOFTWARE\DingueVBS\PickIconIndex"
"HKCU\SOFTWARE\DingueVBS\PickApp"
Delete these keys.

6/ It writes also

"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\ProgramFilesDir"
when this key doesn't exists. 
Do not delete this key unless you realy need to.

-----------
WARNINGS, KNOWN BUGS AND LIMITATIONS

0/ Some programs or sometimes the Operating System itself automaticaly reset context menu in the way you don't like, whatever you are trying to do.
Windows Vista is particularly unpredictable in that respect.
Make sure that it didn't happen by testing all the edited context menus.
Computer reactions are sometimes wierd. What you see will not be always what you get.
If the menu doesn't display or react as expected, try again and maybe then it will work.

1/ Default system menu (cut, copy, create shortcut etc) as well as menu handlers other than Fast Explorer (WinZip, Scan for viruses etc) cannot be edited.

2/ The number of all menu items (normal and Fast Explorer's) per filetype is limited to 50. That doesn't include system menu and menu handlers other than Fast Explorer.

3/ The number of all entries in FastExplorer.ini, all filetypes combined is limited to 100. If needed it can be risen easily by editing the hta code: Look for FastExplItem(100) at beginning of the script and change the numerical value.

4/ While opening an extention for an MS Office file (doc, xls etc), there will be items with a red mention "(+ hex datas)": Do not edit these items unless you know what you are doing.

-----------
FAST EXPLORER AND FESHLEXT.DLL

When installed by Install_FastExplDll.vbs, this dll file will be moved to the FastExplorer folder, usualy "C:\Program Files\FastExplorer".
Then it will be automaticaly registered with regsrv32.exe.

Fast Explorer offers much more possibilities than the ones proposed with my hta application.
To enjoy even more extra features with Fast Explorer, please read Readme_FastExplorer.txt.
You can edit manualy FastExplorer.ini or use a cool interface called FastExplorer.exe available online.
Download:
http://thesoftpro.tripod.com/downloads/fe/
http://thesoftpro.tripod.com/downloads/fe/kb.htm

	FEShlExt.dll and FastExplorer.exe are written by:
	     Alex Yakovlev (Copyright � 1999-2007)
	         http://thesoftpro.tripod.com
	They are Freeware. Distributed "as is". [sic]

-----------
JCB.OCX

When installed by Install_JcbOcx.vbs, this ocx file will be moved to the system folder, usualy "C:\Windows\System".
Then it will be automaticaly registered with regsrv32.exe.

It's an activeX component used in scripts to pick a file or an icon and return the value (path, index) to the script.


          Jcb.ocx is a component written by:
		   JC BELLAMY � 2005
	http://jc.bellamy.free.fr/guestbook.php
	     It's freeware and opensource


===> Special Thanks to Mr Bellamy and Yakovlev who gave us these components!
-----------

FAQ:

There is a .vbs file in the zip file. Is it a virus?
No. It's part of the program.
-----------

TERM OF USE:

The phrase "These softwares" refers to all the scripts, hta applications, executables and programs of every other types contained in this package.

These softwares are free to use and distribute for private and non commercial and non professional purpose. 
These softwares are under copyright protection.

These softwares are provided freely and without warranty. Their authors can not be held responsible for damage, loss of hardware performance, loss of hardware or software functionality, alteration of datas or loss of datas resulting from the direct or indirect use of These softwares.

Informations generated by these softwares MAY DIFFER FROM REALITY and MAY BE MISLEADING and MAY RESULT IN UNEXPECTED REACTIONS FROM YOUR COMPUTER.

				Use at your own risk!
-----------

CONTACT:
e-mail the author at fredledingo@yahoo.com

forum:
-----------

HISTORY:

0.1
-First public Beta release

0.2
-Fixed: Change in filetype settings not taking effect
-Added: Ask to Delete hex datas key "HKCR\[FileType]\shell\[KeyName]\command\command" which prevent changes to take effect eventhought registry are overwritten properly.

0.3
-Fixed item display bug when the item command line doesnt' contain "C:\\".
-Fixed error when extention has no icon set at all, not even a default one.
-Fixed fastExplorer.ini not found or empty while it's not the case

0.4
-Added: Support for Windows XP and Regedit version 5.0

0.5
-Fixed a new bug in reading temp.reg on w98
-Changed default DingueVBS key to "HKCU\SOFTWARE\DingueVBS\" for Vista compliance