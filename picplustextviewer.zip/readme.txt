	Dingue PicPlusTextViewer v 0.4
	==============================
Written by Fredledingue
fredledingo@yahoo.com
________________________________
FEATURES:
-A very simple picture viewer displaying at the same time as a text refering to this picture.
-Texts can be short comments or long descriptions, stories, jokes, etc that you write yourself in notepad
-Supports only picture formats supported by Internet Explorer (jpg, png and gif)
________________________________
SOFTWARE REQUIREMENT
	Windows OS (all versions possibly)
	Windows Script Host 5.6 (Already installed on w2000, XP and w98SE-uSP2)
(If you see an error message, please download it from:
http://www.microsoft.com/downloads/details.aspx?FamilyId=0A8A18F6-249C-4A72-BFCF-FC6AF26DC390&displaylang=en
or
http://msdn.microsoft.com/library/default.asp?url=/downloads/list/webdev.asp )
________________________________
INSTALLATION:
	Unzip the files to a location of your choice.
(No further installation necessary.)
________________________________
HOW TO USE?
(*=version number)

-Double click on PicPlusTextViewer*.hta
-Click once to open a picture or a folder from the list
_______________________________
CREATING OR EDITING COMMENTS FOR THE IMAGES

-Press the "Edit Text" button
-If no text exists, a text file will be created.
-Write your comment or a longer story.
-Press "Save". 
-Press "Cancel" to cancel changes to text. In this case, if a file has been created it will not be deleted.

Or...

-Open Notepad
-Write your comment or a longer story.
-Save the text under exactely the same name as the image, except the extention (extention must be .txt)
(Tip: in Windows Explorer, copy the file nane before writing your comment, then paste the file name when saving the text in notepad.)
_______________________________
HOTKEYS
Press ? to see the keyboard hotkeys.
_______________________________
BUTTONS

[Edit Text]: Create or edit the text for the image
[Zoom in]: Enlarge the image by 1/3
[Zoom out]: Reduce the image by 1/3
[100%]: Display the image back to its original size
[Open]: Return to the list of files and folders
[<--]: Display the previous image in the same folder
[-->]: Display the next image in the same folder
[_]: Minimize ==> [_-]: Maximize
[X]: Exit

CHECK BOXES

From left to right:
1: Display file name and file infos on/off
2: Display text on/off
3: Display text on black/transparent background when overlaping the image (*)

*: The text appears on the right of the picture unless there is no room left for it. When the image cover all the screen, the text is displayed on the picture.
_______________________________

KNOWN BUGS AND LIMITATIONS:

-You can't modify the size of the window: It's either maximized or "reduced".

-You can't realy minimize it. The minimize button will reduce it on a small area in the right bottom of the screen.

-No context menu on the task bar.

-Huge zoom may not display.

-Huge images may take a few seconds to display.
_______________________________

COMMANDLINE

Launch PicPlusTextViewer using the following syntax:
(*=version number)

PicPlusTextViewer*.hta [FolderPath] / [SortBy] / [ViewDetails] / [ExtFilter]

Variable must be separated by "/" and can be written in different order or be obmited.

FolPath : any valid path to a folder or a file
(default: current directory)

SortBy : one of the following value:
    N - by name 
    E - by extension 
    A - by last access date
    S - by size 
    D - by date and time
(default: by name)

ViewDetails : one or more of the following value:
    A -  last access date
    S -  size 
    D -  date and time
    B -  attribute
    L -  full details
(default: no detail)

ExtFilter : extention(s) (without the dot) separated by a comma
	example: jpg,png,
(default: jpg,gif,png,)

_______________________________

HISTORY

0.1 
-Never released

0.2 
-First public release

0.3
-Added Mouse cursor change over selectable items
-Added Keyboard HotKeys

0.4 
-Fixed Many bugs
-Added Message when reaching the beginning or the end of the list
-Added Reloop from the beginning of the list when reaching the end
-Allow Open a file on command line

________________________________
TERM OF USE
	Free for non commercial purpose.
This script is under copyright protection.

This script is provided freely and without warranty. 
The author can not be held responsible for damage or loss of data resulting from the direct or indirect use fo this script.




