# Magic-Notes
A Project using Vanilla JavaScript.You can Add Notes, show all the Notes &amp; also Delete each and every Notes.
