
FixFileName 0.7
=================
Written by Fredledingue
fredledingo@yahoo.com
________________________
DESCRIPTION:
	This VBscript renames files to fit as best as possible the compatibility across operating systems and various data storage supports.
It's useful to fix errors related to bad filenames.

-Rename files by replacing illegal characters which are specific to your language by normal, international ones.

(The wrong characters may be valid within the language set of your computer, but not anymore when you transfer these files to another computer, making the file unreadable.
	For example if one file is named with some polish character, you won't be able to open it on another computer without a polish character set. Even worse: you may even be unable to delete or move this file!)

-Rename files by replacing dots by "_" to avoid extention misunderstanding.

-Delete redundant separators

-Reduces the file name lenghts to a number of characters set by the user.

-Possibility to undo.

-Warning when the user select a system folder 

-Avoid renaming files with system or hidden attribute or in "_file" folders

-If a file has to be renamed by the name of an existing file, a counter will be added at the end of the name.

________________________
REQUIREMENT
	Windows (all versions)
	Windows Script 5.6 (If you see an error message, please download it from:
http://www.microsoft.com/downloads/details.aspx?FamilyId=0A8A18F6-249C-4A72-BFCF-FC6AF26DC390&displaylang=en
or
http://msdn.microsoft.com/library/default.asp?url=/downloads/list/webdev.asp )
________________________
INSTALLATION:
	Unzip the files in a location of your choice
________________________
HOW TO USE:

	1/Double-clic FixFileName.vbs or a shortcut to this file.

	2/Select a folder or a drive

	3/Follow the instructions, it's very easy

	4/A dialog box ask you the maximum number of characters in file names, then for the folder names: It's recommanded that you let the number that appears if you don't know what to do. Enter 1000 or whatever astronomical number if you don't want to shorten long names.
The minimum name lenght you can enter is 8 because under that, I don't think it makes any sens.

	4/Wait: It may take a while when you select a location with lots of files.

	5/If you need to undo some renamings: Double-click "Undo.vbs".
Everytime you will doubleclick "Undo.vbs" it will undo the changes one step back.

Old names and new names informations are stored in NamesBckup_*date*_*time*.txt in the FixFileName.vbs'directory. Once you did an Undo, you can delete "UndoneBackup" files if you want.
Attention: the "Undo" may not be able to rename some files back to formerly impossible names.

_______________________
WHAT THIS PROGRAM IS DOING EXACTELY?

	1/ Look all the files in all the subfolders of the folder you have selected
	2/ Skip folders named with "_files" because they refer to htm pages. If files inside these folders were renamed links in the htm pages won't work anymore.
	3/ Avoid as much as possible system folder or files, or folder or file with special attributes, or give a warning when system sensitive folders could be involved.
	4/ Remove or replace by "_" or replace by the closest alphanumeric most of the special or invalid charaters. Some special characteres such as "$" or "&"  and some others will not be replaced. "(", ")" and "[" and "]" are replaced but files and folders with "{" or "}" are not renamed at all.
	5/ If a file or a folder has to be renamed by a name already existing, the new name is changed and a counter added at the end of the name.
	6/ Shorten the lenght of the name down to a number of characters set by the user + the extention.
	7/  write every change in a text file named "namesbackup"+date and time for possible undo or just for your information.


_______________________
HISTORY
v.0.4
-First public release

v.0.5
-Added Undo
-Delete or replace more invalid or strange characters.

v.0.6
-Bad release

v.0.7
-Fixed errors from version 0.6
-Fixed other small errors
-Added disclaimer message
-Code beautifuly rewritten and other unvisible improvements

________________________
TERM OF USE
	Free for non commercial purpose.
(See copyright information inside the script file.)

	DISCLAIMER: By using this  script you understand that some files will be automaticaly renamed. Thought every precaution has been taken to avoid any risk of losing or modifying data, the author of this script is not responsible for any loss of data caused by the use of this script. Use at your own risk.