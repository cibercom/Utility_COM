	 Files BackUp 0.1(by Fredledingue) -June 2011
	___________________________________

				INTRODUCTION
				______________

DESCRIPTION:

-Quickely track changes in your documents and copy them to one or several location for back up. 
-Allow exclude list, easy configuration, autodect recommanded folders etc.
-Allow exclusion paterns for all folders or for specific folders, file size limit etc
-Faster than similar applications.

This program is designed  to be fast, especialy when checking large numbers of files.
It shows its best performance when dealing with a few new files lost among thousands of unchanged ones.

	ATTENTION: Always proceed manualy and never rely on any software for very important datas!

-----------
OPERATING SYSTEM COMPATIBILITY

- Windows 95:	not tested
- Windows 98:	ok
- Windows XP/Vista/7: should be ok

-----------
SYSTEM REQUIEREMENT: 

NON-UPDATED W98 ATTENTION: 
If you see the red message "Loading datas to memory" for a long time (1 min or so),  install Windows Script Host 5.6. 

It's normaly already installed on every XP, Vista, 7 and updated W98 (uSP2, MDCU etc) platforms.
Link:   http://www.htasoft.com/w98se_post_usp4/SCR579X.EXE
info:    http://www.htasoft.com/w98se_post_usp4/SCR579X.txt

-----------

INSTALLATION:

-Unzip into a folder of your choice. (No further installation necessary.)

- Windows XP and Vista: If you are not logged as administrator when using this program, extract it in "Document" or in "Public". 
(or in one of their subfolder that you can create for this purpose).

- If you need to set up a default program to run hta files, look for "mshta.exe" in "C:\Windows\System".

-Files needed to run the program:

	FilesBackUp.hta
	FilesBackUp*.vbs
	fb_config*.hta

-Doubleclick FilesBackUp*.hta to start the prgram (see more details below)

-By clicking on the "About" button you can check the installation and settings status.

-Don't install Files Back Up  in the same directory as Installed System File Checker or Installed System File BackUp 
(if you don't know what the latters are, just ignore).


			SETTINGS OPTIONS EXPLAINED
			____________________________


THE SETTINGS CONSOLE

[New Back Up Project]
-The first time you use the program, the Settings panel will open automaticaly. 
It will show you a button reading "New Back Up Project". Press this button.
Enter a name for the project.
This name will be the name of the ini file containing the parameters for your new files back up project.
You need at least one project but you can create as many projects as you want to make different types of back ups.
Don't type illegal characters (: < > . , ; ? ! = + * / \ | etc) or character with accents for this name.
When you will run the program you will have to select one project before starting (see "HOW TO USE" below).

- Below, it will help you set up lists of folder to scan and to exclude.
You can also edit the ini files manualy if you know what you are doing. It's not forbidden but it's better that the first time the ini files be created with the program.

-To add a folder in the scan list or in the exclude list you can either enter its full path manualy in the appropriate text box (both long and short paths are allowed) or press the appropriate buttons to select your folder from a directory tree.

-All folders in the scan list must exist. However those in the exclude list doesn't have to.

-To modify the settings of a certain project Double-click "fb_config*.hta" to access the Settings panel directly. 
Or press the button [Change Settings] on the main window of "FilesBackUp*.hta".
In the setting console press:

[Edit Existing Project]
Select the project you want to modify in the drop down box.
Then edit the datas loaded in the form.

[Rename Project]
Will basicaly rename the ini file currently loaded in the settings console.

[Duplicate Project]
Will make a copy of the loaded project under another name and save the settings in this copy.
This is useful to reuse the settings of one project to create a new one.

-You can also edit the ini files in Notepad or rename or create them in Windows Explorer.

-----------
FOLDERS TO SCAN AND TO BACK UP

- "Scan" 
	[] My Documents:
Check this if you simply need to back up all the files from the classic 'My Documents' folder.

	[] E-mails
This will back up the e-mail box files (.dbx) from the Outlook Express folder. 

	Choose folders [Browse for a folder to scan]

In this box you can type or paste a path to a folder to scan and back up the files from.
Click on the button to select the folder from a tree.
Both short paths and long paths are valid.
-----------

FOLDERS TO EXCLUDE

	Exclude folders [Browse for a folder to exclude]

In this box you can type or paste a path to a folder not to scan and which is a subfloder of a folder to scan.
This will make the process significantly faster than using exclusion words (see below).
It's not necessary to include folders which are not subfolders of scanned folders.
Click on the button to select the folder from a tree.
Both short paths and long paths are valid.
-----------

FILTERS

	Exclude files or file paths containing words:  

This function allows a filter to exclude files and/or folders without typing their full path.
Files wille be excluded when one of the words listed in this box is found in their name or, in the cases explained below, in their path.
You can also exclude folders in a different way than in the "Exclude folders" option above.
Here are the main rules and syntax to use the filter.

1/ Each word must be separated by a new line or by a comma.
For example:

temp,test.txt,.avi

or

temp
test.txt
.avi

or

temp, test.txt
.avi

2/ Don't use *. The function equivalent to the DOS * (wildcard) is implemented by default.
If you type a * or any illegal character like < > | ? : " * the word will be ignored and will have no effect.

3/ To exclude folders you must insert their names between "\" or add a "\" at the end.
For example "\temp\" or "temp\"
(without quote marks (") - never use quote marks).
If you type only one "\" at the end, all folders with names ending with this word will be excluded.
(See also "FILTERS IN SPECIFIC FOLDERS" below for more options to play with folders.)

4/ To exclude files, type their names or part of them.
All files with a name containing one of these words will be excluded.
This will not affect folders if it doesn't include "\".

For example 

"temp" will affect all files containing "temp" in their name but won't affect folders.
"\temp\" will affect only folders containing "temp" in their name but won't affect files outside this folder.
"temp\" will affect only folders containing "temp" at the end of their name but won't affect files outside these folders.
"temp\test" will affect only files which names starts by "test" and located in a folder with a name finishing with "temp"
"\temp\test" will affect only files which names starts by "test" and located in a folder named "temp"

5/ Attention: If you use white spaces at the beginning or at the end of the word,
you will be asked if you want to keep these white spaces as part of the word.
This happens when you add a white space before or after a comma.
Click "No" to ignore these white spaces.

For example 
If you write this, you won't be asked no question:

temp,test.txt,.avi

However if you write this:

temp, test, .avi

You will be asked to answer by yes or no, wether you want the white space to be part of the word or not.

If you say yes, only files with names containing " test" will be excluded but not those with names containing "test" without white space.
"1 test.txt" will be excluded while "1test.txt" won't.

If you say no, white space at the beginning and the end of the word will be ignored and both "1 test.txt"and "1test.txt" will be excluded.
However white space inside the word are always used. 
For example "test ok" will never exclude "testok.txt" whatever is the case.

It's best to use space after or before a comma only if this space is used as a part of the word for the filter. 
But the option is kept open for better readability.

6/ Be careful not to type too short words otherwise many files may be unexpectedly omited from the backed up.
For example if you enter:

te, st, 01

...too many files will be excluded. 
Check the log file to see which files have been excluded this way and adapt the filter as necessary in the setting console.

7/ To exclude files by extention, include the extention preceded by the dot (e.g. ".tif")
However this will also exclude files having this word in their name even when it's not their extention.
For example a jpg file named "test.tif.jpg" will also be excluded eventhought its extention is not ".tif".
(It's of course a very bad habit to name files like that but lots of poeple do so.)

8/ You can use short names (8.3 DOS name) for folders but for files only the long names will be checked.
It can be more conveniant and more readable to insert short paths for folders in the list.

For example:

"\TEMPOR~1\" will exclude the folder "Temporary tests" if its dos name is "TEMPOR~1".

But...

"TEMPOR~1" won't exclude any folder (because there is no "\") and will exclude only files with long name containing "TEMPOR~1", no matter their dos name.
It won't exclude "Temporary tests.txt" but it will exclude  "my test for tempor~1.txt".
The dos name is not checked for files. It's checked only for folders.

9/ The filter is not case sensitive.
For example
"TEMP" will exclude "temp.txt" as well as "Temp.txt", "tEMp.txt" and "TEMP.txt".
-----------

FILTERS IN SPECIFIC FOLDERS

	Apply exclusions to specific folders:  [Browse}

In the same box (or by pressing the browse button), you can set rules which will apply only to certain folders.
Attention: the rules will also apply to all of their subfolders.

To do so enter the folder path followed by "?" followed by the words for the filter.
The list of words for this folder will stop at the next mention of a folder path.
You can start the list right after the "?" or at the next line and list them line by line or separated by comas as you wish.

For example:

temp,.avi,.tif
C:\My Documents\Extraction?exp,000
C:\My Documents\Temporary testing?.txt,.gif

or

temp
.avi,.tif
C:\My Documents\Extraction?
exp
000
C:\My Documents\Temporary testing?
.txt, gif

or

temp,.avi,.tif
C:\MYDOCU~1\EXTRAC~1?exp,000
C:\MYDOCU~1\TEMPOR~1?.txt,.gif

In the 3 example above, files with name containing "temp", ".avi" and ".tif" will be excluded in all folders.
Files with name containing "exp" and "000" will be excluded only in the folder "C:\My Documents\Extraction".
Files with name containing ".txt" and ".gif"  will be excluded only in the folder "C:\My Documents\Temporary testing"
Files with name containing "exp", "000", ".txt" and ".gif" will not be excluded in other folders.

It can be more conveniant and more readable to insert short paths for folders in the list.
You can use short names (8.3 DOS name) for folders but for files bear in mind that only the long names will be checked against the filter.
-----------

BACK UP FOLDERS AND DRIVES

	Root folder (or drive) for the 1st back up (required): 

	Root folder (or drive) for the 2d back up (optional): 

	Root folder (or drive) for the 3d back up (optional): 

	Root folder (or drive) for the 4th back up (optional): 

These are the locations where the files will be copied to. At least one location is required (of course otherwise there is nothing to do).
All the others are optional.
Locations should not be on CD or DVD drives because they require special burning softwares unless they are formated for direct writing simulating a hard disk drive, but that's not the best nor the safest use for CD and DVD back ups.
-----------

FILE SIZE LIMIT

	Size limit for the files to back up.

Under each back up location, you can set a file size limit.
If a file exceed the limit entered here, it won't be copied to this back up folder.
If the limit is set to zero (0), then no limit will be applied.
This is useful to avoid excessively large files being copied and wasting disc space.

You must apply a file size limit to each of the location.
This is useful when doing back ups on drives with very different capacities like a seocndary hard disc and a usb stick.
You may want to limit more the size of the files on the usb stick than on the hard disc.

You can choose the unit (byte, Kb, Mb, Gb) in which you write the limit. However the program will always recalculate it in byte whent it writes to the ini files and in Kb in the setting console.
-----------

TRUNCATED DIRECTORY NAME IN BACK UP FOLDERS

	Remove first directory name from the folder paths. 

To shorten access paths in the back up directories, this option will remove the name of the first directory which is often useless.
For example if you back up the folder "C:\My Documents\My Pictures" in "F:\BackUp", it will be saved as ""F:\BackUp\My Pictures".

If this option is checked only the first directory name will be removed and always removed no mater what it is.
For example if you back up the folder "D:\Work\My Pictures" in "F:\BackUp", it will be saved as ""F:\BackUp\My Pictures".

If you have two folder called "My Pictures" which are both second in the folder path tree, their files will be mixed and may overwrite each others in the final back up.
So be careful with this option when doing back up of different sources of datas.
-----------

OTHER BUTTONS

	[Save Settings]
Will save the settings into the ini file. Re-pressing this button will update the ini file again with the datas entered.

	[Start File Back Up]
Will return you to the main window only after having saved the settings.
You know that the settings have been saved when this button is enabled. (Thought there is also a message box.)

	[Help] and [?]
Will show you the main points of this help as a message box. 

	[Cancel]
Will return you to the main window without modifting the settings unless you have already pressed [Save Settings] before.

	[Exit]
Will close the program.

-----------

			HOW IT WORKS
			______________

FIRST BACK UP

The first time you use the program,  a first copy of all the files (save those ecluded of course) will be copied to the back up location(s).
If there is already a back up of these files at these locations, files with the exact acess path and name won't be recopied even if different or older.
This is to make the process faster when working on existing back ups.
To avoid this, run the program twice at the beginning.
The next times the program will detect every changes and update the files accordingly.
-----------

NEXT BACK UPS

Every time you run the program, it compares an actualized list of your files with the list dome at the last back up.
In other words, it compares what is in you documents now with what was there the last time.
Then it will copy the new and the modified files to the back up location(s).

ATTENTION: The program doesn't check what is actualy in the back up folders (except the very first time - see above).
The advantage of this is that you can remove, displace, delete, compress etc files in you back up folders without interference by the program.
For example the files which you deleted because you didn't deem necessary to keep them in the back up or the files which you compressed to save disc space will not be re-copied the next time unless they were modified in the original folder.
If you compress files (in zip, rar etc) in the back up folder, then delete them after compression,  duplicate of these files will appear in the back up only if they are newer than those in the zip files.

If you have doubts and think that some files may have to be reutrned to the back up folder, just delete all the files with "*.txt" extention (*=name of the project) from the folder where this program is installed. Then restart it as if it was the first time.
Or re-use the datas (see "HOW TO REUSE DATAS" below)

Note: You don't need to do this if you have changed the settings.
When the settings are changed, and for example, there is a new folder to check, all the files in this folder will be considered as new and will be copied.
-----------

HOW TO USE:

1/ Doubleclick FilesBackUp*.hta (*=version number)

2/ Select a project from the drop down list.
If you don't select any, the first project showing up in the drop down list will be used.

3/ Click on the "Back Up Files" button.

4/ The lenght of the scan operation should be from instantly to 30 seconds on recent computers. It varies with the amount of changes detected and the number of files and folders to check.
If the program doesn't respond after several minutes, please press Ctrl+Alt+Del and kill the "wscript" or "wscript.exe" task(s) and the "Installed Files Checker" or "mshta.exe" task(s) if any.

Note that under versions of  Windows Script Host inferior to 5.6, the operation is much longer (see warning above).

5/ Press the "Show Settings" button to see them, "Change Settings" to change them or set them the first time.

6/ The lenght of the copy operation varies with the number and size of the files to copy. This is done in DOS with a self-generated batch file.

7/ When the files are being copied to their back up locations, you will see the last progress bar going.
You can also look at the DOS console playing the batch files used to copy files. This DOS console will be minimized in the taskbar.
If there aren't a lot of datas to copy, everyhting will be so fast that you may not see anything. Then a message box will tell you that the operation is finished.

NOTE:
- You can also use FilesBackUp*_html.vbs, but you won't be able to see the progressbar. Use it only if hta support is not installed or not working. They both share and modify the same datas.

*********************************
	   ATTENTION: 
   NEVER doubleclick on fb.bat
      or on other files !!!!
*********************************
-----------

READING THE LOG FILES:

Open or double-click "*.log" in the program folder to view a list of the reports on the recent back up operations.
(* = project name)
This list will NOT include the files copied to the back up locations (that would make the log file too big). It will list only those excluded from the back up through words in their file name or path or because their  sizes exceeded the limit you have set.

-----------
HOW TO REUSE THE BATCH FILE

If the files copying was interrupted  for any reason (computer crash, power outage, BSOD etc) you can restart it by double-clicking on "fbup.bat".
Do so only if you are sure that there was a problem.
 
-----------

UPDATING:

If you have already used a previous version of this program, just unzip the new files to the same directory.
The settings are preserved in the ini file. You don't need to reconfigurate.
*_A.txt, *_B.txt, fb.bat etc are upward compatible: They can be used with new versions...

Always use the vbs or hta files with the highest version number contained in their name.

ATTENTION: Update any shortcut to the new file(s)!

-----------

			FAQ, STATU AND LEGAL INFOS
			____________________________

FAQ:

There is a .vbs file in the zip file. Is it a virus?
No. It's the program.
-----------

TERM OF USE:

"These softwares" refers to all the scripts, hta applications, executables and programs of every other types contained in this package.

These softwares are free to use and distribute for private and non commercial and non professional purpose. 
These softwares are under copyright protection.

These softwares are provided freely and without warranty. Their authors can not be held responsible for damage, loss of hardware performance, loss of hardware or software functionality, alteration of datas or loss of datas resulting from the direct or indirect use of These softwares.

Information generated by  or software MAY DIFFER FROM REALITY and MAY BE MISLEADING.

Use at your own risk.
-----------

CONTACT:
projects@htasoft.com

-----------

HISTORY:

It uses the same comparison engine as in System File Checker, from the same author.
(http://www.htasoft.com/ifc.htm, forum: http://www.msfn.org/board/Installed_System_Files_Checkerhta_t75305.html)

0.1  first public release

